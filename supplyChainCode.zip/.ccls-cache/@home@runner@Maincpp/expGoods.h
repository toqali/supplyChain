#include "prodInfo_struct.h"
#include <iostream>
#include <string>
using namespace std;

// Class definition for exportGoods
class exportGoods {
public:
    // Member variable of type prodInfo
    prodInfo &expPI;
    int opId, id = 0, indexOfImpProd;
    string branchName;
    string expOption[3] = {"View Goods in store", "Distribution Location", "Back to Home Page"};

    // Constructor that initializes pI with provided data
    exportGoods(prodInfo &P): expPI(P) {}

    // Method to display header for export goods
    void header() {
        cout << "\n\t\t\t\t*********** Export Goods ***********\n";
        cout << "\t\t\t\t_____________________________________\n\n";
    }

    // Method to display options for export goods
    void displayOptions() {
        // Display header
        header();
        // Display all options
        for (int id = 0; id < 3; id++) {
            cout << expOption[id] << " #" << id + 1 << endl;
        }
        cout << "Choose id of option : ";
        cin >> opId;
        if (opId == 1) {
            // first option
            viewExportGoods();
        } else if (opId == 2) {
            if (expPI.numOfImpProd != 0) {
                // second option
                distributeGoods();
            } else {
                cout << "There are no goods in store\n";
            }
        }
        backToPreviousPage();
    }

    // Method to view exported goods details
    void viewExportGoods() {
        cout << "\n\t\t\t\t****** View All Products ******\n";
        cout << "\t\t\t\t_______________________________\n\n";

        if (expPI.numOfImpProd != 0) {
            // Show all products
            for (int pId = 0; pId < expPI.numOfImpProd; pId++) {
                cout << expPI.prodName[pId] << " # " << pId + 1 << endl;
            }
            cout << "Choose id of product : ";
            cin >> id;
            // Show details info
            cout << "Product Name : " << expPI.prodName[id - 1] << endl;
            cout << "Date of Reach : " << expPI.reachDate[id - 1] << endl;
            cout << "Location : " << expPI.importLoc[id - 1] << endl;
            cout << "Quantity of products : " << (expPI.impQuantity[id - 1] - expPI.expQuantity[id - 1]) << endl;
            cout << "Cost : " << expPI.ProdCost[id - 1] << endl;
        } else {
            cout << "\n**** There are no products added :( ****" << endl;
        }
    }

    // Method to add goods info that will be distributed
    void distributeGoods() {
        cout << "\n\t\t\t\t****** View All Branches ******\n";
        cout << "\t\t\t\t_______________________________\n\n";

        for (const auto &pair : expPI.expGoodsInfo) {
            cout << pair.first << " #" << id + 1 << endl;
        }
        cout << "Choose Name of Branch : ";
        cin >> branchName;
        while (!isBranchFound(branchName)) {
            cout << "The inserted branch name isn't found, Rechoose Name of Branch : ";
            cin >> branchName;
        }

        // Fill info based on chosen Branches
        fillExpGoodsInfo(branchName);
    }

    // Method to fill export goods information for a specific branch
    void fillExpGoodsInfo(string branch) {
        // Validate that the entered product can be sold
        validateProduct(branch);

        // Check if there is enough quantity of the product to be sold
        if (expPI.impQuantity[indexOfImpProd] != expPI.expQuantity[indexOfImpProd]) {
            // Ensure the entered quantity is enough to be sold
            int prodQuantity = isQuantityEnough(branch);

            // Input the arrival date of the sold product
            cout << "Enter the date of product arrival (dd-mm-yyyy): ";
            cin >> expPI.expGoodsInfo[branch].expArrivalDate[expPI.expGoodsInfo[branch].numOfProdEachBranch];

            // Input the price of the sold product
            cout << "Enter the price of sold product: ";
            cin >> expPI.expGoodsInfo[branch].price[expPI.expGoodsInfo[branch].numOfProdEachBranch];

            // Calculate and store the profit of the sold product
            expPI.expGoodsInfo[branch].profit[expPI.expGoodsInfo[branch].numOfProdEachBranch] =
                (expPI.expGoodsInfo[branch].price[expPI.expGoodsInfo[branch].numOfProdEachBranch] - expPI.ProdCost[indexOfImpProd])
                * prodQuantity;
            cout << "The profit of sold product: " << expPI.expGoodsInfo[branch].profit[expPI.expGoodsInfo[branch].numOfProdEachBranch] << endl;

            // Increase the number of products found in the store
            expPI.expGoodsInfo[branch].numOfProdEachBranch++;

            // Prompt to sell more products
            sellMoreGoods();
        } else {
            // Inform the user that there is not enough quantity to be sold
            cout << "There is not enough quantity to be sold :(" << endl;
        }
    }

    // Method to validate the product that will be sold in a specific branch
    void validateProduct(string branch) {
        cout << "Enter the name of sold product : ";
        // Input the sold name of the product for a specific branch
        cin >> expPI.expGoodsInfo[branch].pn[expPI.expGoodsInfo[branch].numOfProdEachBranch];
        while (!isProdFound(branch)) {
            cout << "\nThe product is not found, please enter the name of the product again : ";
            cin >> expPI.expGoodsInfo[branch].pn[expPI.expGoodsInfo[branch].numOfProdEachBranch];
        }
    }

    // Method to check if the product that will be sold is found in the store
    bool isProdFound(string branch) {
        for (int i = 0; i < expPI.numOfImpProd + 1; i++) {
            if (expPI.expGoodsInfo[branch].pn[expPI.expGoodsInfo[branch].numOfProdEachBranch] == expPI.prodName[i]) {
                indexOfImpProd = i;
                return true;
                break;
            }
        }
        return false;
    }

    // Method to check if the branch name is found in the store
    bool isBranchFound(string &branch) {
        for (const auto &pair : expPI.expGoodsInfo) {
            if (branch == pair.first) {
                return true;
            }
        }
        return false;
    }

    // Method to check if the entered quantity of the sold product is enough
    int isQuantityEnough(string branch) {
        // Calculate the maximum quantity that can be sold
        int maxQuantity = expPI.impQuantity[indexOfImpProd] - expPI.expQuantity[indexOfImpProd];

        // Get the reference to the quantity of the product for the specific branch
        int &branchProductQuantity = expPI.expGoodsInfo[branch].expQuant[expPI.expGoodsInfo[branch].numOfProdEachBranch];

        // Request the user to enter the quantity of the sold product
        cout << "Enter the quantity of sold product: ";
        cin >> branchProductQuantity;

        // Validate the entered quantity
        while (branchProductQuantity > maxQuantity) {
            cout << "The maximum quantity = " << maxQuantity << ". Enter a valid quantity again: ";
            cin >> branchProductQuantity;
        }

        // Update the total exported quantity for the product
        expPI.expQuantity[indexOfImpProd] += branchProductQuantity;
        return branchProductQuantity;
    }

    // Method to prompt to sell more goods
    void sellMoreGoods() {
        char sellMore;
        cout << "Sell more Goods (y/n) : ";
        cin >> sellMore;
        if (sellMore == 'y') {
            distributeGoods(); // Call distributeGoods() to continue selling goods
        }
    }

    // Method to navigate back to the previous page
    void backToPreviousPage() {
        char back;
        cout << "Back to the previous Page (y/n): ";
        cin >> back;
        if (back == 'y') {
            displayOptions(); // Go back to display options menu
        }
    }
};
