#include "prodInfo_struct.h"

// Class definition for Branches
class Branches {
    public:
        // Attributes
        int branchId;
        prodInfo &branchPi;
        char editOption, editNameOption, editLocOption;
        string oldName, newName, newLoc, branchLoc;
        string branchOptions[4] = {"View Branches", "Add new Branch", "Delete Branch", "Edit Branch's info"};
    
        // Constructor that initializes branchPi with provided data
        Branches(prodInfo &P): branchPi(P) {}
    
        // Method to add header of options
        void header() {
            cout << "\n\t\t\t\t************ Our Branches ************\n";
            cout << "\t\t\t\t______________________________________\n\n";
        }
    
        // Method to display main options for branches
        void displayOptions() {
            int opBranchId;
            // Display header
            header();
    
            // Display all options
            for (int id = 0; id < 4; id++) {
                cout << branchOptions[id] << " #" << id + 1 << endl;
            }
            cout << "Choose number of option: ";
            cin >> opBranchId;
    
            // Execute the selected option
            switch(opBranchId) {
                case 1: {
                    viewAllBranches();
                    backToMainOptionMenu();
                    break;
                }
                case 2: {
                    addBranch();
                    backToMainOptionMenu();
                    break;
                }
                case 3: {
                    deleteBranch();
                    backToMainOptionMenu();
                    break;
                }
                case 4: {
                    editBranchInfo();
                    backToMainOptionMenu();
                    break;
                }
            }
        }
    
        // Method to view all existing branches
        void viewAllBranches() {
            branchId = 0;
            cout << "\n\t\t\t\t********* View All Branches *********\n";
            cout << "\t\t\t\t_____________________________________\n\n";
    
            // Iterate through all branches and display their names
            for (const auto &pair : branchPi.expGoodsInfo) {
                cout << pair.first << " #" << branchId + 1 << endl;
                branchId++;
            }
        }
    
        // Method to add a new branch
        void addBranch() {
            branchId = 0;
            string branchName;
    
            // Input new branch name and location
            cout << "Enter name of branch you want to add : ";
            cin >> branchName;
            cout << "Enter location of branch : ";
            cin >> branchLoc;
    
            // Add new branch to expGoodsInfo and branchInfo maps
            branchPi.expGoodsInfo[branchName] = prodInfo::ExpGoodsInfo();
            branchInfo[branchName] = branchLoc;
    
            cout << "The branch has been added successfully." << endl;
    
            // Display all branches after addition
            for (const auto &pair : branchPi.expGoodsInfo) {
                cout << pair.first << " #" << branchId + 1 << endl;
                branchId++;
            }
        }
    
        // Method to delete an existing branch
        void deleteBranch() {
            branchId = 0;
            string deletedBranchName;
    
            // Input branch name to delete
            cout << "Enter name of branch you want to delete : ";
            cin >> deletedBranchName;
    
            // Ensure branch exists and delete it
            deletedBranchName = ensureBranchExists(deletedBranchName);
            branchPi.expGoodsInfo.erase(deletedBranchName);
            branchInfo.erase(deletedBranchName);
    
            cout << "The branch has been deleted successfully." << endl;
    
            // Display all remaining branches
            for (const auto &pair : branchPi.expGoodsInfo) {
                cout << pair.first << " #" << branchId + 1 << endl;
                branchId++;
            }
        }
    
        // Method to edit branch's information
        void editBranchInfo() {
            cout << "Edit Branch's info (y/n) : ";
            cin >> editOption;
    
            // If user wants to edit, proceed to change name and location
            if (editOption == 'y') {
                changeBranchName();
                changeBranchLoc();
            }
        }
    
        // Method to change branch name
        void changeBranchName() {
            cout << "Change Name of Branch (y/n) : ";
            cin >> editNameOption;
    
            // If user wants to change name, proceed
            if (editNameOption == 'y') {
                cout << "Enter Name of branch you want to change : ";
                cin >> oldName;
    
                // Ensure branch exists and change its name
                oldName = ensureBranchExists(oldName);
                cout << "Enter New Name of branch : ";
                cin >> newName;
    
                // Update branch name in expGoodsInfo and branchInfo maps
                branchPi.expGoodsInfo[newName] = branchPi.expGoodsInfo[oldName];
                branchPi.expGoodsInfo.erase(oldName);
                branchInfo[newName] = branchInfo[oldName];
                branchInfo.erase(oldName);
    
                cout << "The branch name has been changed successfully." << endl;
            } else {
                cout << "No changes have been made to the branch name." << endl;
            }
        }
    
        // Method to change branch location
        void changeBranchLoc() {
            string brName, newLoc;
    
            cout << "Change Location of Branch (y/n) : ";
            cin >> editLocOption;
    
            // If user wants to change location, proceed
            if (editLocOption == 'y') {
                cout << "Enter the name of branch you want to change its location: ";
                cin >> brName;
    
                // Ensure branch exists and change its location
                brName = ensureBranchExists(brName);
                cout << "Enter New Location: ";
                cin >> newLoc;
    
                // Update branch location in branchInfo map
                branchInfo[brName] = newLoc;
    
                cout << "Location updated successfully." << endl;
            } else {
                cout << "No changes made to the branch location." << endl;
            }
        }
    
        // Method to ensure branch exists before performing operations
        string ensureBranchExists(string branchName) {
            // Loop until valid branch name is entered
            while (branchPi.expGoodsInfo.find(branchName) == branchPi.expGoodsInfo.end()) {
                cout << "The branch you entered does not exist, please try again : ";
                cin >> branchName;
            }
            return branchName;
        }
    
        // Method to navigate back to the main options menu
        void backToMainOptionMenu() {
            char isDesireToBack;
            cout << "Back to Main Branch Menu (y/n): ";
            cin >> isDesireToBack;
    
            // If user wants to go back, display main options menu again
            if (isDesireToBack == 'y') {
                displayOptions();
            }
        }
};
