#include <iostream>
using namespace std;
#include "impGoods.h"  // Include header for imported goods
#include "expGoods.h"  // Include header for exported goods
#include "prodInfo_struct.h" // Include header for product information structure
#include "Branches.h" // Include header for branches
#include "statistics.h" // Include header for statistics

// Forward declarations of functions
void backToHome();
void showDetailsMainMenu(int optionNum);

// Array of menu options
string options[4] = {"Imported Goods", "Exported Goods", "Our Branches", "Statistics"};
int opNum = sizeof(options) / sizeof(options[0]); // Calculate number of menu options
prodInfo prInfo; // Create a prodInfo object
importGoods imGood; // Create an importGoods object

// Function to show details based on the selected menu option
void showDetailsMainMenu(int optionNum) {
    switch(optionNum) {
        case 1: {
            cout << endl;
            imGood.addGoods(prInfo.numOfImpProd); // Add imported goods
            prInfo = imGood.show(); // Show imported goods
            backToHome(); // Go back to home
            break;
        }
        case 2: {
            cout << endl;
            exportGoods exGoods(prInfo); // Create an exportGoods object
            exGoods.displayOptions(); // Display export options
            backToHome(); // Go back to home
            break;	
        }
        case 3: {
            Branches br(prInfo); // Create a Branches object
            br.displayOptions(); // Display branch options
            backToHome(); // Go back to home
            break;
        }
        case 4: {
            Statistics st(prInfo); // Create a Statistics object
            st.calculateExportPercentage(); // Calculate and display export percentage
            backToHome(); // Go back to home
            break;
        }
        default:
            cout << "Invalid Input, You didn't enter a valid option number." << endl;
            backToHome(); // Go back to home
    }
}

// Function to display the main menu and handle user input
void showMainMenu() {
    int optionNum;
    cout << "\n\t\t\t\t************* Main Menu *************\n";
    cout << "\t\t\t\t_____________________________________\n\n";
    for(int opID = 1; opID <= opNum; opID++) {
        cout << options[opID - 1] << " #" << opID << endl; // Display menu options
    }
    cout << "Choose number of option: ";
    cin >> optionNum; // Get user input
    showDetailsMainMenu(optionNum); // Show details for the selected option
}

// Function to navigate back to the main menu
void backToHome() {
    char addOp;
    cout << "\nBack to the Home Page (y/n): ";
    cin >> addOp; // Get user input
    if (addOp == 'y') {
        showMainMenu(); // Display main menu
    }
}
