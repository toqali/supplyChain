#include <iostream>
using namespace std;

class login {
public:
    // attributes
    int maxTries;
    bool isValid;
    string allowedUsers[5] = {"Toqa", "Ahmad", "Mohammad", "Omar", "Salma"};
    string validPassword[5]  = {"12345678", "asdfghjk", "ZXCVBNM,", "13579246", "Salma123"};
    int length;

    // constructor
    login(int mx = 3) {
        maxTries = mx;
        isValid = false; // Initialize isValid to false in constructor
        length = 5; // Assign the size of the array manually
    }

    // first method: add header of option
    void header(){
        cout << "\t\t\t\t ** Welcome to Supply Chain System **" << endl ;
        cout << "\t\t\t\t ____________________________________\n\n" ;
    }

    // second method: is Input info Valid
    bool isInputValid(string userName, string passWord) {
        for (int indx = 0; indx < length; ++indx) {
            if (allowedUsers[indx] == userName && validPassword[indx] == passWord) {
                return true;
            }
        }
        return false;
    }

    // third method: input username & password and give only 3 attempts
    bool userLogin() {
        string inputUsername;
        string inputPass;
        int initialmaxTries = 0;
        // display header
        header();
        while (initialmaxTries < maxTries) {
            if (initialmaxTries == 0) {
                cout << "Enter Username : ";
                cin >> inputUsername;
                cout << "Enter Password : ";
                cin >> inputPass;
            } else {
                cout << "--- Invalid Username or Password ---" << endl;
                cout << "Enter Username again : ";
                cin >> inputUsername;
                cout << "Enter Password again : ";
                cin >> inputPass;
            }

            if (isInputValid(inputUsername, inputPass)) {
                isValid = true;
                break;
            }
            initialmaxTries++;
        }

        return isValid;
    }
};
