#include "prodInfo_struct.h"

class Statistics {
    public:
        prodInfo &prodInfoEachBranch; // Reference to the product information structure
        int branchId; // Variable to store branch ID
        map<string, int> Prod_Quantity; // Map to store the quantity of imported products by product name
    
        // Constructor to initialize the reference to product information
        Statistics(prodInfo &P) : prodInfoEachBranch(P) {}
    
        // Method to display the header for the statistics section
        void header() {
            cout << "\n\t\t\t\t************ Some Statistics ************\n";
            cout << "\t\t\t\t______________________________________\n\n";
        }
    
        // Method to calculate and display the export percentage for each branch
        void calculateExportPercentage() {
            float expPercent; // Variable to store the export percentage
            float soldQuantity, purchasedQuantity, totalProfit = 0; 
            string branchName; // Variable to store the current branch name
            int numOfProd; // Variable to store the number of products in the current branch
            header(); // Display the header
            createMapQuantity(); // Populate the map with product quantities
    
            // Loop over each branch in the expGoodsInfo map
            for (auto &pair : prodInfoEachBranch.expGoodsInfo) {
                totalProfit = 0;
                branchName = pair.first; // Get the branch name
                cout << branchName << endl; // Print the branch name
                numOfProd = prodInfoEachBranch.expGoodsInfo[branchName].numOfProdEachBranch;
                // Check if there are exported products for the branch
                if (numOfProd != 0) {
                    cout << "\t\t\tExport Percent:\n";
                    // Loop over the exported products for the branch
                    for (int prodId = 0; prodId < numOfProd ; prodId++) {
                        soldQuantity = pair.second.expQuant[prodId]; // Get the sold quantity
                        purchasedQuantity = Prod_Quantity[pair.second.pn[prodId]]; // Get the purchased quantity
                        expPercent = soldQuantity / purchasedQuantity; // Calculate the export percentage
                        cout << "\t\t\t\t\t" << pair.second.pn[prodId] << " : " << expPercent * 100 << "%\n"; // Print the export percentage
                        totalProfit += prodInfoEachBranch.expGoodsInfo[branchName].profit[prodId]; // Calculate the total profit]
                    }
                    cout << "\t\t\tTotal Profit : " << totalProfit << endl;
                } else {
                    cout << "\t\t\t\t----No Products----\n"; // Print message if no products are exported
                }
            }
        }
    
        // Method to populate the map with imported product quantities
        void createMapQuantity() {
            for (int i = 0; i < prodInfoEachBranch.numOfImpProd; i++) {
                Prod_Quantity[prodInfoEachBranch.prodName[i]] = prodInfoEachBranch.impQuantity[i]; // Add product name and quantity to the map
            }
        }
};
