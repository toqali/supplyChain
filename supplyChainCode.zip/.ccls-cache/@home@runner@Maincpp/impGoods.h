#include <limits>
#include <string>
#include "prodInfo_struct.h"
using namespace std;

// Class definition for importGoods
class importGoods {
public:
    prodInfo pI; // Instance of prodInfo to store imported goods
    string options[4] = {"Imported Goods", "Exported Goods", "Our Branches", "Statistics"};
    int opNum = sizeof(options) / sizeof(options[0]);
    char addOp;
    int indx = 0; // Index to track the number of goods added

    // Method to display header for import goods
    void header() {
        cout << "\n\t\t\t\t*********** Import Goods ***********\n";
        cout << "\t\t\t\t_____________________________________\n\n";
    }

    // Method to add goods information
    void addGoods(int indx) {
        header();

        cout << "Enter the name of imported product : ";
        cin >> pI.prodName[indx];

        cout << "\nEnter the date of reach of Products (dd-mm-yyyy): ";
        cin >> pI.reachDate[indx];

        cout << "\nEnter the Import Location : ";
        cin >> pI.importLoc[indx];

        cout << "\nEnter number of Products are imported : ";
        cin >> pI.impQuantity[indx];
        while (cin.fail()) {
            cout << "\nInvalid input! Expected an integer.\n";
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Enter number of Products are imported : ";
            cin >> pI.impQuantity[indx];
        }

        cout << "\nEnter the cost of product : ";
        cin >> pI.ProdCost[indx];
        while (cin.fail()) {
            cout << "\nInvalid input! Expected a float.\n";
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Enter the cost of product : ";
            cin >> pI.ProdCost[indx];
        }

        pI.numOfImpProd++; // Increment the number of imported products
        addMoreGoods(); // Ask if more goods need to be added
    }

    // Method to print the last added goods
    void printGoods() {
        cout << "\nLast added goods:\n";
        cout << "Product Name : " << pI.prodName[indx] << endl;
        cout << "Date of Reach : " << pI.reachDate[indx] << endl;
        cout << "Location : " << pI.importLoc[indx] << endl;
        cout << "Quantity of products : " << pI.impQuantity[indx] << endl;
        cout << "Cost : " << pI.ProdCost[indx] << endl;
    }

    // Method to add more goods if confirmed by the user
    void addMoreGoods() {
        char addMore;
        cout << "Add more Goods (y/n) : ";
        cin >> addMore;
        if (addMore == 'y') {
            indx++;
            addGoods(indx); // Recursively add more goods
        } else {
            backToPreviousPage(); // If not adding more, go back to previous page
        }
    }

    // Method to navigate back to the previous page
    void backToPreviousPage() {
        cout << "Back to the previous Page (y/n): ";
        cin >> addOp;
        if (addOp == 'y') {
            printGoods(); // Print the last added goods
        }
    }

    // Method to return the prodInfo struct
    prodInfo show() {
        return pI;
    }
};
