#ifndef PRODINFO_STRUCT_H
#define PRODINFO_STRUCT_H

#include <iostream>
#include <map>
using namespace std;

// Define the structure for product information
struct prodInfo {
    // Arrays to store product information
    string prodName[20];
    string importLoc[20];
    string reachDate[20];
    int impQuantity[20];
    int expQuantity[20];
    float ProdCost[20];
    int numOfImpProd = 0; // Number of imported products
    int numOfExpProd = 0; // Number of exported products

    // Structure for storing export goods information per branch
    struct ExpGoodsInfo {
        string pn[20]; // Product names
        string expArrivalDate[20]; // Arrival dates of exported products
        float price[20]; // Prices of exported products
        int expQuant[20]; // Quantities of exported products
        float profit[20]; // Profits from selling products
        int numOfProdEachBranch = 0; // Number of products per branch
    };

    // Map to store export goods information for each branch
    map<string, ExpGoodsInfo> expGoodsInfo = {
        {"Branch1", {}},
        {"Branch2", {}},
        {"Branch3", {}},
        {"Branch4", {}},
        {"Branch5", {}}
    };
};

// Map to store branch names and their locations
map<string, string> branchInfo = {
    {"Branch1", "Irbid"},
    {"Branch2", "Amman"},
    {"Branch3", "Aqaba"},
    {"Branch4", "Al-Tafeeleh"},
    {"Branch5", "Maan"}
};

#endif // PRODINFO_STRUCT_H
