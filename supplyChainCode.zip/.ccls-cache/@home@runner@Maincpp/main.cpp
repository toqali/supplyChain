#include "loginScreen.h" // Include the login screen 
#include "mainMenu.h"    // Include the main menu 

int main() {
  // Login screen
  login lg; // Create a login object
  lg.userLogin(); 

  // Display main menu
  showMainMenu(); 
}
